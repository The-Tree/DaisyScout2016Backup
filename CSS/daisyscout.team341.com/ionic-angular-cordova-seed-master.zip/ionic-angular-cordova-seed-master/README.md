ionic-angular-cordova-seed
==========================

The perfect starting point for an Ionic project.

- [Ionic Tutorials](http://ionicframework.com/tutorials/)